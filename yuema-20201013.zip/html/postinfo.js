//前台信息投稿附加JS函数
function EmpireCMSQInfoPostFun(obj,mid){
	return true;
}


//后台发布信息附加JS函数
function EmpireCMSInfoPostFun(obj,mid){
	return true;
}