<?php
if(!defined('InEmpireCMS'))
{exit();}
?>