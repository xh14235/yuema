$('.phone-menu-toggle').click(function () {
  $('.phone-list').toggleClass('phone-list-toggle')
})